defmodule Ms2ex.Metadata.Animation do
  defstruct [:model, :sequences]

  def id(), do: :model
end
