defmodule Ms2ex.Metadata.Ride do
  defstruct [:id, :model, :basic, :speed, :stats]

  def id(), do: :id
end
