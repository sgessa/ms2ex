defmodule Ms2ex.Metadata.Script do
  defstruct [:id, :type, :states]

  def id(), do: :id
end
