defmodule Ms2ex.Metadata.NxsMesh do
  defstruct [:index, :data]

  def id(), do: :index
end
