defmodule Ms2ex.Metadata.Ugcmap do
  defstruct [:id, :plots]

  def id(), do: :id
end
